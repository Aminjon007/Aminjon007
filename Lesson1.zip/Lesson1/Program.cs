﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

// Объявление и инициализация переменных
int age = 25; // Целочисленный тип
age = 10;
double height = 1.75; // Число с плавающей точкой
string name = "Иван"; // Строка
bool isStudent = true; // Логическое значение (истина/ложь)

// Вывод значений переменных на экран
Console.WriteLine($"Имя: {name}");
Console.WriteLine("Возраст: " + age);
Console.WriteLine("Рост: " + height + " м");
Console.WriteLine("Студент: " + isStudent);

//// Ввод имени
//Console.Write("Введите ваше имя: ");
//string name = Console.ReadLine();

//// Ввод возраста
//Console.Write("Введите ваш возраст: ");
//int age = int.Parse(Console.ReadLine());

//// Вывод сообщения с использованием введенных данных
//Console.WriteLine($"Привет, {name}! Вам {age} лет.");

// Набор операций
//int a = 3;
//int b = 5;
//int c = 40;
//int d = c-- - b * a;    // a=3  b=5  c=39  d=25
//Console.WriteLine($"a={a}  b={b}  c={c}  d={d}");